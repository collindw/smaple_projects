from selenium import webdriver
from selenium.webdriver.common.keys import Keys
#from selenium.webdriver.support.select import Select
#from selenium.webdriver.support.ui import WebDriverWait
#from selenium.webdriver.common.by import By
import time
import pandas as pd

path = '/usr/local/share/chromedriver'
#option = webdriver.ChromeOptions()
#option.add_argument('headless')
driver = webdriver.Chrome(path)  #, options=option



driver.get('https://sis.henrico.k12.va.us/teachers/pw.html')  #enter website url here
my_username = 'dwcollins'
my_password = 'Baxterbutt45!!'



##go to website and log in with my credentials
login = driver.find_element_by_name('username')
password = driver.find_element_by_name('password')

login.send_keys(my_username)
password.send_keys(my_password, Keys.ENTER)

##automatically click link/steps to get to gradebook
driver.implicitly_wait(0.5)

#open directed study section
gradebook_link = driver.find_element_by_id('navPowerTeacherPro-367103').click()
driver.implicitly_wait(5)

#different approach.  click on download report to an excel file and get scores from there
time.sleep(5)
scoresheet_button = driver.find_element_by_id('sidebar-charms-reports').click()
driver.implicitly_wait(10)

#click open scoresheet report page
scoresheet_report = driver.find_element_by_id('reports-scoresheetReport-link').click()
driver.implicitly_wait(10)

#format to excel file
format = driver.find_element_by_xpath('//*[@id="content-main"]/div[4]/div/div/div/div/ul/li[3]/a').click()
time.sleep(1)

excel_format = driver.find_element_by_xpath('//*[@id="output"]/span[2]').click() # clicks on format button
time.sleep(1)

select_excel = driver.find_element_by_xpath('//*[@id="output-1"]').click() #clicks on excel
time.sleep(1)

#run report, then view, then download excel file
run_report = driver.find_element_by_xpath('//*[@id="footer-save-button"]').click()
time.sleep(1)

view_report = driver.find_element_by_xpath('//*[@id="report-queue-link-button"]/var').click()
time.sleep(1)

#download spreadsheet
download_grades = driver.find_element_by_partial_link_text('Scoresheet').click() #should download spreadsheet
time.sleep(2)

#close browser
driver.close()


###############################################
#use pandas to get spreadsheet

gradebook = pd.read_excel('/home/dev/Downloads/scoresheetReport.xlsx')  #using pandas, attempt to load data
gradebook['testing_things2'] = ((18-gradebook['testing_things'])/3) # gives students 1/3 of the points they lost on quiz
corrections = round(gradebook['testing_things2'],1) 

quiz_grades = gradebook['testing_things']

#sample test.  I chose a calculation that should round a decimil down to make sure the worst case fails (index 7)
# (18-17)/3 should be 0.3 if decimil is cut off after 10's place


expected = 0.3
actual = round((18-quiz_grades[7])/3, 1)  #had to add round().  Was returning 0.3 vs. 0.3333.....
print('expected value is ' +str(expected))
print('actual value is ' + str(actual))


#here is the simple calculation test
if expected == actual:
    print('passed sample calculation')
else:
    print('FAILED sample calculation')