#https://youtu.be/G9qUehRYEwI

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By

path = '/usr/local/share/chromedriver'
driver = webdriver.Chrome(path)
#driver.implicitly_wait(3)

driver.get('https://amazon.com')

search = driver.find_element(By.ID, 'twotabsearchtextbox')
search.send_keys('wireless headphones', Keys.ENTER)

expected_text = '" headphones"'
actual_text = driver.find_element(By.XPATH, "//span[@class='a-color-state a-text-bold']").text

assert expected_text == actual_text, f'Error. Expected text {expected_text}, but actual text: {actual_text}'
driver.quit()